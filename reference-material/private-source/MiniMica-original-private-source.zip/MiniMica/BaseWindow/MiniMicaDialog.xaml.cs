﻿using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace MiniMica
{
    /// <summary>
    /// Interaction logic for MiniMicaDialog.xaml
    /// </summary>
    public partial class MiniMicaDialog : Window
    {
        // Cached light/dark theme state for better performance
        private bool _isLightTheme;
        private bool _isPreviousHighContrast;

        public MiniMicaDialog()
        {
            InitializeComponent();
            _isPreviousHighContrast = SystemParameters.HighContrast;

            IntPtr hWnd = new WindowInteropHelper(GetWindow(this)).EnsureHandle();
            var attribute = MiniMicaGUI.DWMWINDOWATTRIBUTE.DWMWA_WINDOW_CORNER_PREFERENCE;
            var preference = MiniMicaGUI.DWM_WINDOW_CORNER_PREFERENCE.DWMWCP_ROUND;
            MiniMicaGUI.DwmSetWindowAttribute(hWnd, attribute, ref preference, sizeof(uint));
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            var hwndSource = HwndSource.FromHwnd(new WindowInteropHelper(this).Handle);
            hwndSource.AddHook(WndProc);
            UpdateTheme();  // Initial theme apply
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            // Define Win32 constants
            const int WM_ACTIVATEAPP = 0x001C;
            //const int WM_SYSCOMMAND = 0x0112;
            const int WM_INITMENUPOPUP = 0x0117;
            const int WM_SETTINGCHANGE = 0x001A;
            const int WM_THEMECHANGED = 0x031A;

            const uint SC_MAXIMIZE = 0xF030;
            const uint SC_RESTORE = 0xF120;
            const uint SC_MOVE = 0xF010;
            const uint SC_SIZE = 0xF000;

            const uint MF_BYCOMMAND = 0x00000000;
            const uint MF_GRAYED = 0x00000001;
            const uint MF_ENABLED = 0x00000000;

            if (msg == WM_ACTIVATEAPP)
            {
                if (wParam.ToInt32() != 0)
                {
                    if (this.WindowState == WindowState.Minimized)
                        this.WindowState = WindowState.Normal;
                    this.Activate();
                    this.Topmost = true;
                    this.Topmost = false;
                    this.Focus();
                }
            }

            if (msg == WM_INITMENUPOPUP)
            {
                IntPtr systemMenu = MiniMicaGUI.GetSystemMenu(hwnd, false);
                MiniMicaGUI.EnableMenuItem(systemMenu, SC_MAXIMIZE, MF_BYCOMMAND | MF_GRAYED);
                MiniMicaGUI.EnableMenuItem(systemMenu, SC_RESTORE, MF_BYCOMMAND | MF_GRAYED);
                MiniMicaGUI.EnableMenuItem(systemMenu, SC_MOVE, MF_BYCOMMAND | MF_ENABLED);
                MiniMicaGUI.EnableMenuItem(systemMenu, SC_SIZE, MF_BYCOMMAND | MF_GRAYED);
            }

            if (msg == WM_SETTINGCHANGE || msg == WM_THEMECHANGED)
            {
                UpdateTheme();
            }

            return IntPtr.Zero;
        }

        private void UpdateTheme()
        {
            bool isCurrentHighContrast = SystemParameters.HighContrast;

            if (SystemParameters.HighContrast)
            {
                // Set the high contrast outer border (the "purple" or highlight color)
                WindowFrame.Background = SystemColors.WindowBrush;
                WindowFrame.BorderBrush = SystemColors.WindowFrameBrush;
                WindowFrame.BorderThickness = new Thickness(MiniMicaGUI.WindowFrameThickness);

                ContentCtrl.UpdateTheme(true);
            }
            else
            {
                _isLightTheme = MiniMicaGUI.IsLightThemeEnabled();

                // Hide outer border for non-HC themes
                WindowFrame.Background = _isLightTheme ? (Brush)FindResource("MicaBackground_L") : (Brush)FindResource("MicaBackground_D");
                WindowFrame.BorderBrush = Brushes.Transparent;
                WindowFrame.BorderThickness = new Thickness(0);

                ContentCtrl.UpdateTheme(_isLightTheme);

                // Force shadow refresh when exiting High Contrast mode
                if (_isPreviousHighContrast && !isCurrentHighContrast)
                    RefreshWindowShadow();
            }

            _isPreviousHighContrast = isCurrentHighContrast;
            UpdateTitleBarTheme();
        }

        /// <summary>
        /// Updates the title bar controls based on the current theme and activation state.
        /// </summary>
        private void UpdateTitleBarTheme()
        {
            if (SystemParameters.HighContrast)
            {
                btnClose.Style = (Style)this.FindResource("CloseButton_HC");
                //gridSpacer.Width = 6;

                // High contrast window frame
                textMain.Foreground = this.IsActive ? SystemColors.ActiveCaptionTextBrush : SystemColors.InactiveCaptionTextBrush;
                WindowFrame.BorderBrush = this.IsActive ? SystemColors.ActiveCaptionBrush : SystemColors.InactiveCaptionBrush;
                titleBarBehind.Fill = this.IsActive ? SystemColors.ActiveCaptionBrush : SystemColors.InactiveCaptionBrush;
            }
            else
            {
                if (this.IsActive)
                {
                    if (_isLightTheme)
                    {
                        btnClose.Style = (Style)this.FindResource("CloseButton_L_Activated");
                        textMain.Foreground = Brushes.Black;
                    }
                    else
                    {
                        btnClose.Style = (Style)this.FindResource("CloseButton_D_Activated");
                        textMain.Foreground = Brushes.White;
                    }
                }
                else // Window is deactivated
                {
                    if (_isLightTheme)
                    {
                        btnClose.Style = (Style)this.FindResource("CloseButton_L_Deactivated");
                        textMain.Foreground = Brushes.Silver;
                    }
                    else
                    {
                        btnClose.Style = (Style)this.FindResource("CloseButton_D_Deactivated");
                        textMain.Foreground = Brushes.Gray;
                    }
                }
                //gridSpacer.Width = 0;
                titleBarBehind.Fill = Brushes.Transparent;
            }
        }

        private async void RefreshWindowShadow()
        {
            if (this.WindowState == WindowState.Minimized)
                return;

            var hwnd = new WindowInteropHelper(this).Handle;

            // Force a minimize, delay, and restore to re-attach the WindowChrome shadow
            MiniMicaGUI.ShowWindow(hwnd, MiniMicaGUI.SW_MINIMIZE);
            await Task.Delay(100);
            MiniMicaGUI.ShowWindow(hwnd, MiniMicaGUI.SW_RESTORE);
            this.Activate();
            this.Focus();
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BtnMinimize_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void MouseLeftButton_Down(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void OnActivated(object sender, EventArgs e)
        {
            UpdateTitleBarTheme();
        }

        private void OnDeactivated(object sender, EventArgs e)
        {
            UpdateTitleBarTheme();
        }

        // Disable Maximize command
        private void OnStateChanged(object sender, EventArgs e)
        {
            if (this.WindowState == System.Windows.WindowState.Maximized)
                this.WindowState = System.Windows.WindowState.Normal;
        }
    }
}
