﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace MiniMica
{
    public partial class MiniMicaWindow : Window
    {
        public bool IsStartMaximized { get; set; } = false;
        private bool _isLightTheme;
        private bool _isPreviousHighContrast;
        private bool _isPseudoMaximized = false;
        private Rect _restoreBounds;
        private bool _isDraggingFromMaximized = false;
        private Point _dragStartPoint;

        public MiniMicaWindow()
        {
            InitializeComponent();
            _isPreviousHighContrast = SystemParameters.HighContrast;

            IntPtr hWnd = new WindowInteropHelper(GetWindow(this)).EnsureHandle();
            var attribute = MiniMicaGUI.DWMWINDOWATTRIBUTE.DWMWA_WINDOW_CORNER_PREFERENCE;
            var preference = MiniMicaGUI.DWM_WINDOW_CORNER_PREFERENCE.DWMWCP_ROUND;
            MiniMicaGUI.DwmSetWindowAttribute(hWnd, attribute, ref preference, sizeof(uint));
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            if (this.IsStartMaximized)
                TogglePseudoMaximize();

            // In High Contrast mode, set default window width 4*2 pt wider to include the border
            if (SystemParameters.HighContrast)
                SnapWindowSizesHC();

            var hwndSource = HwndSource.FromHwnd(new WindowInteropHelper(this).Handle);
            hwndSource.AddHook(WndProc);
            UpdateTheme();
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            const int WM_ACTIVATEAPP = 0x001C;
            const int WM_SYSCOMMAND = 0x0112;
            const int WM_INITMENUPOPUP = 0x0117;
            const int WM_SETTINGCHANGE = 0x001A;
            const int WM_THEMECHANGED = 0x031A;

            const uint SC_MAXIMIZE = 0xF030;
            const uint SC_RESTORE = 0xF120;
            const uint SC_MOVE = 0xF010;
            const uint SC_SIZE = 0xF000;

            const uint MF_BYCOMMAND = 0x00000000;
            const uint MF_GRAYED = 0x00000001;
            const uint MF_ENABLED = 0x00000000;

            if (msg == WM_ACTIVATEAPP)
            {
                if (wParam.ToInt32() != 0)
                {
                    if (this.WindowState == WindowState.Minimized)
                        this.WindowState = WindowState.Normal;
                    this.Activate();
                    this.Topmost = true;
                    this.Topmost = false;
                    this.Focus();
                }
            }

            if (msg == WM_INITMENUPOPUP)
            {
                IntPtr systemMenu = MiniMicaGUI.GetSystemMenu(hwnd, false);
                if (_isPseudoMaximized)
                {
                    MiniMicaGUI.EnableMenuItem(systemMenu, SC_MAXIMIZE, MF_BYCOMMAND | MF_GRAYED);
                    MiniMicaGUI.EnableMenuItem(systemMenu, SC_RESTORE, MF_BYCOMMAND | MF_ENABLED);
                    MiniMicaGUI.EnableMenuItem(systemMenu, SC_MOVE, MF_BYCOMMAND | MF_GRAYED);
                    MiniMicaGUI.EnableMenuItem(systemMenu, SC_SIZE, MF_BYCOMMAND | MF_GRAYED);
                }
                else
                {
                    MiniMicaGUI.EnableMenuItem(systemMenu, SC_MAXIMIZE, MF_BYCOMMAND | MF_ENABLED);
                    MiniMicaGUI.EnableMenuItem(systemMenu, SC_RESTORE, MF_BYCOMMAND | MF_GRAYED);
                    MiniMicaGUI.EnableMenuItem(systemMenu, SC_MOVE, MF_BYCOMMAND | MF_ENABLED);
                    MiniMicaGUI.EnableMenuItem(systemMenu, SC_SIZE, MF_BYCOMMAND | MF_ENABLED);
                }
            }

            if (msg == WM_SYSCOMMAND)
            {
                int command = wParam.ToInt32() & 0xFFF0;
                if (command == SC_MAXIMIZE)
                {
                    TogglePseudoMaximize();
                    handled = true;
                }
                else if (command == SC_RESTORE && _isPseudoMaximized && this.WindowState != WindowState.Minimized)
                {
                    TogglePseudoMaximize();
                    handled = true;
                }
            }

            if (msg == WM_SETTINGCHANGE || msg == WM_THEMECHANGED)
            {
                // In High Contrast mode, set default window width 4*2 pt wider to include the border
                if (SystemParameters.HighContrast)
                    SnapWindowSizesHC();

                UpdateTheme();
            }

            return IntPtr.Zero;
        }

        private void SnapWindowSizesHC()
        {
            if (this.Width >= 960 && this.Width < 960 + MiniMicaGUI.WindowFrameThickness * 2)
                this.Width = 960 + MiniMicaGUI.WindowFrameThickness * 2;
        }

        private void UpdateTheme()
        {
            bool isCurrentHighContrast = SystemParameters.HighContrast;

            if (isCurrentHighContrast)
            {
                this.DropShadow.Opacity = 0;
                this.CanvasBorder.Background = SystemColors.WindowBrush;
                this.CanvasBorder.BorderBrush = SystemColors.WindowFrameBrush;

                // Set the high contrast outer border and background
                WindowFrame.Background = SystemColors.WindowBrush;
                WindowFrame.BorderBrush = SystemColors.ActiveCaptionBrush;
                WindowFrame.BorderThickness = _isPseudoMaximized ? new Thickness(0) : new Thickness(MiniMicaGUI.WindowFrameThickness);

                //WindowFrame.CornerRadius = new CornerRadius(0);
                ContentCtrl.UpdateTheme(true);
            }
            else
            {
                _isLightTheme = MiniMicaGUI.IsLightThemeEnabled();
                this.DropShadow.Color = _isLightTheme ? (Color)FindResource("MicaDropShadow_L") : (Color)FindResource("MicaDropShadow_D");
                this.DropShadow.Opacity = _isLightTheme ? 0.25 : 0.75;
                this.CanvasBorder.Background = _isLightTheme ? (Brush)FindResource("MicaBackground_L") : (Brush)FindResource("MicaBackground_D");
                this.CanvasBorder.BorderBrush = new SolidColorBrush(Color.FromArgb(0x20, 0x80, 0x80, 0x80));    // #20808080

                // Hide outer border for non-HC themes
                WindowFrame.Background = _isLightTheme ? (Brush)FindResource("MicaBackground_L") : (Brush)FindResource("MicaBackground_D");
                WindowFrame.BorderBrush = Brushes.Transparent;
                WindowFrame.BorderThickness = new Thickness(0);

                ContentCtrl.UpdateTheme(_isLightTheme);

                // Force the window to minimize and restore in order to correctly display the dropshadow
                // Inlcusing an async delay so the Desktop Window Manager (DWM) has enough time to register the state change
                if (_isPreviousHighContrast && !isCurrentHighContrast)
                    RefreshWindowShadow();
            }

            _isPreviousHighContrast = isCurrentHighContrast;
            UpdateTitleBarTheme();
        }

        private void UpdateTitleBarTheme()
        {
            if (SystemParameters.HighContrast)
            {
                btnClose.Style = (Style)this.FindResource("CloseButton_HC");
                btnMaximize.Style = (Style)this.FindResource("MaximizeButton_HC");
                btnMinimize.Style = (Style)this.FindResource("MinimizeButton_HC");
                btnSettings.Style = (Style)this.FindResource("SettingsButton_HC");
                btnMaximize.Content = _isPseudoMaximized ? "\uE923" : "\uE922";
                //gridSpacer.Width = 6;     // No longer need to set the gridSpacer as the round corner is now handled by DWM

                // High contrast window frame
                textMain.Foreground = this.IsActive ? SystemColors.ActiveCaptionTextBrush : SystemColors.InactiveCaptionTextBrush;
                WindowFrame.BorderBrush = this.IsActive ? SystemColors.ActiveCaptionBrush : SystemColors.InactiveCaptionBrush;
                titleBarBehind.Fill = this.IsActive ? SystemColors.ActiveCaptionBrush : SystemColors.InactiveCaptionBrush;
            }
            else
            {
                if (this.IsActive)
                {
                    if (_isLightTheme)
                    {
                        btnClose.Style = (Style)this.FindResource("CloseButton_L_Activated");
                        btnMaximize.Style = (Style)this.FindResource("MaximizeButton_L_Activated");
                        btnMinimize.Style = (Style)this.FindResource("MinimizeButton_L_Activated");
                        btnSettings.Style = (Style)this.FindResource("SettingsButton_L_Activated");
                        textMain.Foreground = Brushes.Black;
                    }
                    else
                    {
                        btnClose.Style = (Style)this.FindResource("CloseButton_D_Activated");
                        btnMaximize.Style = (Style)this.FindResource("MaximizeButton_D_Activated");
                        btnMinimize.Style = (Style)this.FindResource("MinimizeButton_D_Activated");
                        btnSettings.Style = (Style)this.FindResource("SettingsButton_D_Activated");
                        textMain.Foreground = Brushes.White;
                    }
                }
                else
                {
                    if (_isLightTheme)
                    {
                        btnClose.Style = (Style)this.FindResource("CloseButton_L_Deactivated");
                        btnMaximize.Style = (Style)this.FindResource("MaximizeButton_L_Deactivated");
                        btnMinimize.Style = (Style)this.FindResource("MinimizeButton_L_Deactivated");
                        btnSettings.Style = (Style)this.FindResource("SettingsButton_L_Deactivated");
                        textMain.Foreground = Brushes.Silver;
                    }
                    else
                    {
                        btnClose.Style = (Style)this.FindResource("CloseButton_D_Deactivated");
                        btnMaximize.Style = (Style)this.FindResource("MaximizeButton_D_Deactivated");
                        btnMinimize.Style = (Style)this.FindResource("MinimizeButton_D_Deactivated");
                        btnSettings.Style = (Style)this.FindResource("SettingsButton_D_Deactivated");
                        textMain.Foreground = Brushes.Gray;
                    }
                }
                btnMaximize.Content = _isPseudoMaximized ? "\uE923" : "\uE922";
                //gridSpacer.Width = 0;
                titleBarBehind.Fill = Brushes.Transparent;
            }
        }

        private async void RefreshWindowShadow()
        {
            // Do not perform this if the window is maximized or already minimized
            if (_isPseudoMaximized || this.WindowState == WindowState.Minimized)
                return;

            var hwnd = new WindowInteropHelper(this).Handle;

            // Force a minimize, delay, and restore
            MiniMicaGUI.ShowWindow(hwnd, MiniMicaGUI.SW_MINIMIZE);
            await Task.Delay(100);
            MiniMicaGUI.ShowWindow(hwnd, MiniMicaGUI.SW_RESTORE);
            this.Activate();
            this.Focus();
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e) => this.Close();
        private void BtnMaximize_Click(object sender, RoutedEventArgs e) => TogglePseudoMaximize();
        private void BtnMinimize_Click(object sender, RoutedEventArgs e) => this.WindowState = WindowState.Minimized;

        private void BtnSettings_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new MiniMicaDialog();
            dialog.Owner = this;
            dialog.ShowDialog();
        }

        private void MouseLeftButton_Down(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2) TogglePseudoMaximize();
            else if (e.ClickCount == 1)
            {
                if (_isPseudoMaximized)
                {
                    _isDraggingFromMaximized = true;
                    _dragStartPoint = this.PointToScreen(e.GetPosition(this));
                    Mouse.Capture(this);
                }
                else this.DragMove();
            }
        }

        private void OnActivated(object sender, EventArgs e) => UpdateTitleBarTheme();
        private void OnDeactivated(object sender, EventArgs e) => UpdateTitleBarTheme();

        private void TogglePseudoMaximize()
        {
            if (_isPseudoMaximized)
            {
                this.Top = _restoreBounds.Top;
                this.Left = _restoreBounds.Left;
                this.Width = _restoreBounds.Width;
                this.Height = _restoreBounds.Height;
                LayoutRoot.Margin = new Thickness(0);
                _isPseudoMaximized = false;
                MicaWindowChrome.ResizeBorderThickness = new Thickness(8);
                MicaWindowChrome.GlassFrameThickness = new Thickness(1);

                // Show border when restored
                if (SystemParameters.HighContrast)
                    WindowFrame.BorderThickness = new Thickness(MiniMicaGUI.WindowFrameThickness);
            }
            else
            {
                _restoreBounds = new Rect(this.Left, this.Top, this.Width, this.Height);
                var windowHandle = new WindowInteropHelper(this).Handle;
                System.Windows.Forms.Screen currentScreen = System.Windows.Forms.Screen.FromHandle(windowHandle);
                var workingAreaPixels = currentScreen.WorkingArea;
                PresentationSource source = PresentationSource.FromVisual(this);
                if (source == null) return;
                Matrix matrix = source.CompositionTarget.TransformToDevice;
                double totalBorderThickness = (MiniMicaGUI.GetSystemMetrics(32) + MiniMicaGUI.GetSystemMetrics(92)) / matrix.M11;
                this.Top = (workingAreaPixels.Top / matrix.M22) - totalBorderThickness;
                this.Left = (workingAreaPixels.Left / matrix.M11) - totalBorderThickness;
                this.Width = (workingAreaPixels.Width / matrix.M11) + (totalBorderThickness * 2);
                this.Height = (workingAreaPixels.Height / matrix.M22) + (totalBorderThickness * 2);
                LayoutRoot.Margin = new Thickness(totalBorderThickness);
                _isPseudoMaximized = true;
                MicaWindowChrome.ResizeBorderThickness = new Thickness(0);
                MicaWindowChrome.GlassFrameThickness = new Thickness(0);

                // Hide border when maximized
                if (SystemParameters.HighContrast)
                    WindowFrame.BorderThickness = new Thickness(0);
            }

            UpdateTitleBarTheme();
        }

        private void OnMouseMove(object sender, MouseEventArgs e)
        {
            if (_isDraggingFromMaximized && e.LeftButton == MouseButtonState.Pressed)
            {
                var currentPosition = this.PointToScreen(e.GetPosition(this));
                Vector dragDelta = currentPosition - _dragStartPoint;
                if (Math.Abs(dragDelta.X) > SystemParameters.MinimumHorizontalDragDistance ||
                    Math.Abs(dragDelta.Y) > SystemParameters.MinimumVerticalDragDistance)
                {
                    _isDraggingFromMaximized = false;
                    _isPseudoMaximized = false;
                    this.Width = _restoreBounds.Width;
                    this.Height = _restoreBounds.Height;
                    MicaWindowChrome.ResizeBorderThickness = new Thickness(8);
                    MicaWindowChrome.GlassFrameThickness = new Thickness(1);
                    LayoutRoot.Margin = new Thickness(0);

                    // Show border when dragged-to-restore
                    if (SystemParameters.HighContrast)
                    {
                        WindowFrame.BorderThickness = new Thickness(MiniMicaGUI.WindowFrameThickness);
                        //this.BorderBrush = SystemColors.WindowFrameBrush;
                        //this.BorderThickness = new Thickness(1);
                    }

                    PresentationSource source = PresentationSource.FromVisual(this);
                    if (source == null) return;
                    Matrix matrix = source.CompositionTarget.TransformToDevice;
                    Point currentPositionDIU = new Point(currentPosition.X / matrix.M11, currentPosition.Y / matrix.M22);
                    this.Top = currentPositionDIU.Y - 15;
                    this.Left = currentPositionDIU.X - (this.Width / 2);
                    Mouse.Capture(null);
                    var windowHelper = new WindowInteropHelper(this);
                    MiniMicaGUI.SendMessage(windowHelper.Handle, 0x00A1, new IntPtr(2), IntPtr.Zero);
                    UpdateTitleBarTheme();
                }
            }
        }

        private void OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            _isDraggingFromMaximized = false;
            Mouse.Capture(null);
        }

        private void ScrollLeft_Click(object sender, RoutedEventArgs e) => ContentScroller.LineLeft();
        private void ScrollRight_Click(object sender, RoutedEventArgs e) => ContentScroller.LineRight();

        private void UpdateScrollButtonsVisibility()
        {
            btnScrollLeft.Visibility = ContentScroller.ScrollableWidth > 0 ? Visibility.Visible : Visibility.Collapsed;
            btnScrollRight.Visibility = ContentScroller.ScrollableWidth > 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private void OnWindowSizeChanged(object sender, SizeChangedEventArgs e)
        {
            this.Dispatcher.BeginInvoke(new Action(() => UpdateScrollButtonsVisibility()), System.Windows.Threading.DispatcherPriority.Background);
        }
    }
}
