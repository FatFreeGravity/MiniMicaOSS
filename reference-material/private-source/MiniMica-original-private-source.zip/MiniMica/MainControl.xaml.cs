﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MiniMica
{
    /// <summary>
    /// Interaction logic for MainControl.xaml
    /// </summary>
    public partial class MainControl : UserControl
    {
        public MainControl()
        {
            InitializeComponent();
        }

        // MiniMicaWindow calls this method to update theme colors
        public void UpdateTheme(bool isLightTheme)
        {
            if (SystemParameters.HighContrast)
            {
                // SystemColors
                // https://learn.microsoft.com/en-us/dotnet/api/system.windows.systemcolors?view=netframework-4.8
                // ActiveBorderBrush / InactiveBorderBrush
                // ActiveCaptionBrush / InactiveCaptionBrush
                // ActiveCaptionTextBrush / InactiveCaptionTextBrush
                // InactiveSelectionHighlightBrush
                // AppWorkspaceBrush
                // ControlBrush / ControlTextBrush
                // ControlDarkBrush / ControlLightBrush
                // ControlDarkDarkBrush / ControlLightLightBrush
                // DesktopBrush
                // GradientActiveCaptionBrush / GradientInactiveCaptionBrush
                // GrayTextBrush
                // HighlightBrush / HighlightTextBrush
                // HotTrackBrush
                // InfoBrush / InfoTextBrush
                // MenuBarBrush / MenuBrush / MenuHighlightBrush / MenuTextBrush
                // ScrollBarBrush
                // WindowBrush / WindowFrameBrush / WindowTextBrush

                // Is the High Contrast theme black or white overall?
                bool isHCWhite = (SystemColors.WindowColor.G >= 128);

                // Overriding semantic colors with System Brushes
                textTitle.Foreground = SystemColors.WindowTextBrush;
                textSubtitle.Foreground = SystemColors.WindowTextBrush;

                // In High Contrast, we usually hide or simplify images that might interfere with legibility
                // or use specific high-contrast versions if available.
                textIcon1.Source = isHCWhite ?
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet1_l.png", UriKind.Absolute)) :
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet1_d.png", UriKind.Absolute));
                textIcon2.Source = isHCWhite ?
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet2_l.png", UriKind.Absolute)) :
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet2_d.png", UriKind.Absolute));
                textIcon3.Source = isHCWhite ?
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet3_l.png", UriKind.Absolute)) :
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet3_d.png", UriKind.Absolute));

                textBullet1a.Foreground = SystemColors.WindowTextBrush;
                textBullet1b.Foreground = SystemColors.WindowTextBrush;
                textBullet2a.Foreground = SystemColors.WindowTextBrush;
                textBullet2b.Foreground = SystemColors.WindowTextBrush;
                textBullet3a.Foreground = SystemColors.WindowTextBrush;
                textBullet3b.Foreground = SystemColors.WindowTextBrush;

                btnAction.Style = (Style)this.FindResource("ContosoActionButton_HC");
            }
            else
            {
                // Existing Light/Dark logic
                textTitle.Foreground = isLightTheme ? (Brush)FindResource("ContosoFont_L") : (Brush)FindResource("ContosoFont_D");
                textSubtitle.Foreground = isLightTheme ? (Brush)FindResource("ContosoTeal_L") : (Brush)FindResource("ContosoTeal_D");

                textIcon1.Source = isLightTheme ?
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet1_l.png", UriKind.Absolute)) :
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet1_d.png", UriKind.Absolute));
                textIcon2.Source = isLightTheme ?
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet2_l.png", UriKind.Absolute)) :
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet2_d.png", UriKind.Absolute));
                textIcon3.Source = isLightTheme ?
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet3_l.png", UriKind.Absolute)) :
                    new BitmapImage(new Uri("pack://application:,,,/res/bullet3_d.png", UriKind.Absolute));

                textBullet1a.Foreground = isLightTheme ? (Brush)FindResource("ContosoFont_L") : (Brush)FindResource("ContosoFont_D");
                textBullet1b.Foreground = isLightTheme ? (Brush)FindResource("ContosoFont_L") : (Brush)FindResource("ContosoFont_D");
                textBullet2a.Foreground = isLightTheme ? (Brush)FindResource("ContosoFont_L") : (Brush)FindResource("ContosoFont_D");
                textBullet2b.Foreground = isLightTheme ? (Brush)FindResource("ContosoFont_L") : (Brush)FindResource("ContosoFont_D");
                textBullet3a.Foreground = isLightTheme ? (Brush)FindResource("ContosoFont_L") : (Brush)FindResource("ContosoFont_D");
                textBullet3b.Foreground = isLightTheme ? (Brush)FindResource("ContosoFont_L") : (Brush)FindResource("ContosoFont_D");

                btnAction.Style = isLightTheme ? (Style)this.FindResource("ContosoActionButton_L") : (Style)this.FindResource("ContosoActionButton_D");
            }
        }

        private void BtnTest_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new MiniMicaDialog();
            dialog.Owner = Window.GetWindow(this);
            //dialog.textSample.Text = "LayoutRoot Sizes = " + CtrlRoot.ActualWidth + ", " + CtrlRoot.ActualHeight;
            bool? result = dialog.ShowDialog();
        }
    }
}
