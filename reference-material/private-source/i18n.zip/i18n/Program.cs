﻿using CsvHelper;
using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace i18n
{
    internal class Program
    {
        static List<string> listResourceID;
        static List<string[]> listRecords;

        static void Main()
        {
            // Source i18n .csv file
            //string csvFile = @"C:\V4N\CUA\i18n\i18n-resx\worksheet.csv";
            string csvFile = @"C:\GSA\Jumpstart Partners\ExpressVPN\202508 ExpressVPN Update\i18n-resx\worksheet.csv";
            string dirWork = Path.GetDirectoryName(csvFile);
            //string dirWorkResx = Path.Combine(dirWork, "resx");
            string dirWorkResx = Path.Combine(dirWork, "bin");     // Work directory will be ignored by GitHub
            string templateFile = Path.Combine(dirWork, $"template.resx");
            Console.WriteLine($"Translated CSV: {csvFile}");
            Console.WriteLine($"Template RESX: {templateFile}");
            if (!Directory.Exists(dirWorkResx))
                Directory.CreateDirectory(dirWorkResx);

            listResourceID = new List<string>();
            listRecords = new List<string[]>();

            // Read original translations in .csv file
            ReadI18nCSV(csvFile);
            Console.WriteLine();

            // Output i18n .resx files
            foreach (string culture in cultures)
            {
                string outFile = Path.Combine(dirWorkResx, $"Strings.{culture}.resx");
                GenerateResx(outFile, culture, templateFile);
                Console.WriteLine($"Done: {outFile}");
            }
            Console.WriteLine();

            // Rename .resx files to minimica_culture
            RenameCulture(dirWorkResx);
        }

        static void RenameCulture(string dirWorkResx)
        {
            for (int i = 0; i < cultures.Length; i++)
            {
                string culture = cultures[i];
                string miniCulture = minimica_cultures[i];
                string fileOld = Path.Combine(dirWorkResx, $"Strings.{culture}.resx");
                string fileNew = Path.Combine(dirWorkResx, $"Strings.{miniCulture}.resx");
                if (culture == "en-US")
                    fileNew = Path.Combine(dirWorkResx, $"Strings.resx");

                if (culture == miniCulture)
                {
                    Console.WriteLine($"Skipped: {fileOld} -> {fileNew}");
                    continue;
                }

                if (File.Exists(fileOld))
                {
                    if (File.Exists(fileNew))
                        File.Delete(fileNew);
                    File.Move(fileOld, fileNew);
                    Console.WriteLine($"Renamed: {fileOld} -> {fileNew}");
                }
            }
        }

        static void GenerateResx(string outFile, string culture, string templateFile)
        {
            if (File.Exists(outFile))
                File.Delete(outFile);

            string[] template = File.ReadAllLines(templateFile);

            int index = Array.IndexOf(cultures, culture);
            if (index < 0)
            {
                Console.WriteLine($"Culture not found: {culture}");
                return;
            }

            StreamWriter writer = new StreamWriter(outFile, true, new UTF8Encoding(true));

            foreach (string line in template)
            {
                if (line.Contains("<!--INSERT-->"))
                {
                    for (int i = 0; i < listResourceID.Count; i++)
                    {
                        string resourceID = listResourceID[i];
                        string value = listRecords[i][index];
                        writer.WriteLine($"  <data name=\"{resourceID}\" xml:space=\"preserve\">");
                        writer.WriteLine($"    <value>{System.Security.SecurityElement.Escape(value)}</value>");
                        writer.WriteLine($"  </data>");
                    }

                    // Finally, add the minimica_culture entry
                    string minimica_culture = minimica_cultures[index];
                    writer.WriteLine($"  <data name=\"minimica_culture\" xml:space=\"preserve\">");
                    writer.WriteLine($"    <value>{minimica_culture}</value>");
                    writer.WriteLine($"  </data>");
                }
                else
                {
                    // Just copy the line
                    writer.WriteLine(line);
                }
            }

            writer.Close();
        }

        static void ReadI18nCSV(string csvFile)
        {
            StreamReader reader;
            CsvReader csv;

            try
            {
                reader = new StreamReader(csvFile);
                csv = new CsvReader(reader, CultureInfo.InvariantCulture);
            }
            catch (Exception)
            {
                Console.WriteLine($"Error reading file: {csvFile}");
                return;
            }   

            var csvRecords = csv.GetRecords<I18nRecord>().ToList();
            Console.WriteLine($"# of records: {csvRecords.Count}");

            foreach (I18nRecord csvRecord in csvRecords)
            {
                Console.WriteLine($"ResourceID: {csvRecord.ResourceID}, en-US: {csvRecord.enUS}");

                string[] content = new string[cultures.Length];

                for (int i = 0; i < cultures.Length; i++)
                {
                    var prop = csvRecord.GetType().GetProperty(cultures[i].Replace("-", ""));
                    if (prop != null)
                    {
                        var value = prop.GetValue(csvRecord);
                        content[i] = value?.ToString() ?? "";
                    }
                }

                listResourceID.Add(csvRecord.ResourceID);
                listRecords.Add(content);
            }

            // Data sizes
            Console.WriteLine($"# of records: {listRecords.Count}");
            Console.WriteLine($"# of cultures: {listRecords[0].Length}");
        }

        private static string[] cultures = {
            "en-US", "zh-TW", "zh-CN", "nl-NL", "fr-FR", "de-DE", "it-IT", "pl-PL", "pt-BR", "pt-PT",
            "ru-RU", "es-MX", "es-ES", "uk-UA", "da-DK", "cs-CZ", "fi-FI", "ja-JP", "ko-KR", "nb-NO",
            "sv-SE", "tr-TR", "id-ID", "th-TH", "vi-VN"
        };

        private static string[] minimica_cultures = {
            "en", "zh", "zh-CN", "nl", "fr", "de", "it", "pl", "pt", "pt-PT",
            "ru", "es", "es-ES", "uk", "da", "cs", "fi", "ja", "ko", "nb",
            "sv", "tr", "id", "th", "vi"
        };
    }

    public class I18nRecord
    {
        public string ResourceID { get; set; }

        [Name("en-US")]
        public string enUS { get; set; }
        [Name("zh-TW")]
        public string zhTW { get; set; }
        [Name("zh-CN")]
        public string zhCN { get; set; }
        [Name("nl-NL")]
        public string nlNL { get; set; }
        [Name("fr-FR")]
        public string frFR { get; set; }
        [Name("de-DE")]
        public string deDE { get; set; }
        [Name("it-IT")]
        public string itIT { get; set; }
        [Name("pl-PL")]
        public string plPL { get; set; }
        [Name("pt-BR")]
        public string ptBR { get; set; }
        [Name("pt-PT")]
        public string ptPT { get; set; }
        [Name("ru-RU")]
        public string ruRU { get; set; }
        [Name("es-MX")]
        public string esMX { get; set; }
        [Name("es-ES")]
        public string esES { get; set; }
        [Name("uk-UA")]
        public string ukUA { get; set; }
        [Name("da-DK")]
        public string daDK { get; set; }
        [Name("cs-CZ")]
        public string csCZ { get; set; }
        [Name("fi-FI")]
        public string fiFI { get; set; }
        [Name("ja-JP")]
        public string jaJP { get; set; }
        [Name("ko-KR")]
        public string koKR { get; set; }
        [Name("nb-NO")]
        public string nbNO { get; set; }
        [Name("sv-SE")]
        public string svSE { get; set; }
        [Name("tr-TR")]
        public string trTR { get; set; }
        [Name("id-ID")]
        public string idID { get; set; }
        [Name("th-TH")]
        public string thTH { get; set; }
        [Name("vi-VN")]
        public string viVN { get; set; }
    }
}
